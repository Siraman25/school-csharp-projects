﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SerialPortDemo
{
    class Bits
    {
        //System.Windows.Forms.RadioButton[] radioButtons = new System.Windows.Forms.RadioButton[64];
        //System.Windows.Forms.Panel[] panels = new System.Windows.Forms.Panel[64];

        //const int topx = 433;
        //const int topy = 133;
        //const int gap = 20;

        //for (int x = 0; x < 8; ++x)
        //{
        //    for (int y = 0; y < 8; ++y)
        //    {
        //        //this.panel1.Controls.Add(this.radioButton1);
        //        //this.panel1.Location = new System.Drawing.Point(436, 50);
        //        //this.panel1.Name = "panel1";
        //        //this.panel1.Size = new System.Drawing.Size(21, 33);
        //        //this.panel1.TabIndex = 16;



        //        radioButtons[x + y] = new RadioButton();
        //        radioButtons[x+y].Text = "";
        //        radioButtons[x+y].Location = new System.Drawing.Point(0, 0);
        //        radioButtons[x+y].Size = new System.Drawing.Size(16, 17);
        //        //radioButtons[x+y].AutoCheck = false;
        //        this.Controls.Add(radioButtons[x+y]);

        //        panels[x + y] = new Panel();
        //        //panels[x + y].Name = "panel" + Convert.ToString(x+y);
        //        panels[x + y].BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        //        panels[x + y].Location = new System.Drawing.Point(topx + x * gap, topy + y * gap);
        //        panels[x + y].Size = new System.Drawing.Size(30, 30);
        //        //panels[x + y].Controls.Add(radioButtons[x + y]);

        //    }
        //}
    }
}
